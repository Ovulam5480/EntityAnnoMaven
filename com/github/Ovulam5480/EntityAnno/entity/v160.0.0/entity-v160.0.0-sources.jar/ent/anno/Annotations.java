package ent.anno;

import java.lang.annotation.*;

/**
 * Source-level annotations to generate entity classes from components.
 *
 * @author GlFolker
 * @author Anuke
 */
public final class Annotations{
    private Annotations(){
        throw new AssertionError();
    }

    /** Defines a class providing static entries of IO handlers. */
    @Target(ElementType.TYPE)
    @Retention(RetentionPolicy.CLASS)
    public @interface TypeIOHandler{
    }

    /** Indicates that this class is an entity component. */
    @Target(ElementType.TYPE)
    @Retention(RetentionPolicy.CLASS)
    public @interface EntityComponent{
        /** @return Whether this is a fetched component; in that case, do not generate interfaces. */
        boolean vanilla() default false;

        /** @return Whether the component should generate a base class for itself. */
        boolean base() default false;
    }

    /** All entity components will inherit from this. */
    @Target(ElementType.TYPE)
    @Retention(RetentionPolicy.CLASS)
    public @interface EntityBaseComponent{
    }

    /** Whether this interface wraps an entity component. */
    @Target(ElementType.TYPE)
    @Retention(RetentionPolicy.CLASS)
    public @interface EntityInterface{
    }

    /** Generates an entity definition from given components. */
    @Target({ElementType.TYPE, ElementType.FIELD})
    @Retention(RetentionPolicy.CLASS)
    public @interface EntityDef{
        /** @return The interfaces that will be inherited by the generated entity class. */
        Class<?>[] value();

        /** @return Whether the class can serialize itself. */
        boolean serialize() default true;

        /** @return Whether the class can write/read to/from save files. */
        boolean genIO() default true;

        /** @return Whether the class is poolable. */
        boolean pooled() default false;

        /** @return How component type parameters are supplied to this entity. */
        GenericMode genericMode() default GenericMode.NONE;

        /** @return The shared entity type parameter name in PRESERVE mode. */
        String genericName() default "T";

        /** @return A fully qualified Java reference type in BIND mode, including type arguments. */
        String genericType() default "";

        enum GenericMode{
            NONE, PRESERVE, BIND, SELF
        }
    }

    /**
     * Based on usage:
     * <ul>
     *   <li> When used to annotate an entity class, indicates the class should be mapped in {@code EntityRegistry}.
     *   <li> When used to annotate a {@code public static UnitType} fields, indicates that the unit types' constructor
     *        should use that class. Note that {@link #value()} must be written in this case.
     * </ul>
     */
    @Target({ElementType.TYPE, ElementType.FIELD})
    @Retention(RetentionPolicy.CLASS)
    public @interface EntityPoint{
        /** @return The unit constructor class when annotating a field. Leave untouched otherwise. */
        Class<?> value() default Void.class;
    }

    /** Indicates that a field will be interpolated when synced. */
    @Target({ElementType.FIELD})
    @Retention(RetentionPolicy.CLASS)
    public @interface SyncField{
        /** @return True if the field is linearly interpolated. Otherwise, it's interpolated as an angle. */
        boolean value();

        /** @return True if the field is clamped to 0-1. */
        boolean clamped() default false;
    }

    /** Indicates that a field will not be read from the server when syncing the local player state. */
    @Target({ElementType.FIELD})
    @Retention(RetentionPolicy.CLASS)
    public @interface SyncLocal{
    }

    /** Indicates that a field should not be synced to clients (but may still be non-transient) */
    @Target({ElementType.FIELD})
    @Retention(RetentionPolicy.CLASS)
    public @interface NoSync{
    }

    /** Indicates that a field should be synced, but not serialized */
    @Target({ElementType.FIELD})
    @Retention(RetentionPolicy.CLASS)
    public @interface NoSerialize{
    }

    /** Indicates that the field annotated with this came from another component class. */
    @Target(ElementType.FIELD)
    @Retention(RetentionPolicy.CLASS)
    public @interface Import{
    }

    /** Won't generate a setter for this field. */
    @Target(ElementType.FIELD)
    @Retention(RetentionPolicy.CLASS)
    public @interface ReadOnly{
    }

    /** Whether this method replaces the actual method in the base class. */
    @Target(ElementType.METHOD)
    @Retention(RetentionPolicy.CLASS)
    public @interface Replace{
        /** @return The priority of this replacer. */
        float value() default 0f;
    }

    /** Whether this method is implemented in compile-time. */
    @Target(ElementType.METHOD)
    @Retention(RetentionPolicy.CLASS)
    public @interface InternalImpl{
    }

    /** Used for method appender sorting. */
    @Target(ElementType.METHOD)
    @Retention(RetentionPolicy.CLASS)
    public @interface MethodPriority{
        /** @return The priority. */
        float value();
    }

    /** Appends this {@code add()}/{@code remove()} method before the {@code if([!]added)} check. */
    @Target(ElementType.METHOD)
    @Retention(RetentionPolicy.CLASS)
    public @interface BypassGroupCheck{
    }

    /** Will not replace {@code return;} to {@code break [block];}, hence breaking the entire method statement. */
    @Target(ElementType.METHOD)
    @Retention(RetentionPolicy.CLASS)
    public @interface BreakAll{
    }

    /** Removes a component-specific method implementation. */
    @Target(ElementType.METHOD)
    @Retention(RetentionPolicy.CLASS)
    public @interface Remove{
        /** @return The component specification to remove. */
        Class<?> value();
    }

    /** Will only implement this method if the entity inherits these certain components. */
    @Target(ElementType.METHOD)
    @Retention(RetentionPolicy.CLASS)
    public @interface Extend{
        /** @return The component specification to check. */
        Class<?>[] value();

        /** @return {@code true} if only one component needs to be extended, {@code false} otherwise. */
        boolean any() default false;
    }

    /** Inserts this parameter-less method into another void method. */
    @Target(ElementType.METHOD)
    @Retention(RetentionPolicy.CLASS)
    public @interface Insert{
        /**
         * @return The target method described in {@link String} with the format {@code <methodName>(<paramType>...)}.
         * For example, when targeting {@code void call(String arg, int prior)}, the target descriptor must be
         * {@code call(java.lang.String, int)}
         */
        String value();

        /** @return The component-specific method implementation to target. */
        Class<?> block() default Void.class;

        /** @return Whether the call to this method is after the default or not. */
        boolean after() default true;
    }

    /** Wraps a component-specific method implementation with this boolean parameterless method. */
    @Target(ElementType.METHOD)
    @Retention(RetentionPolicy.CLASS)
    public @interface Wrap{
        /**
         * @return The target method described in {@link String} with the format {@code <methodName>(<paramType>...)}.
         * For example, when targeting {@code void call(String arg, int prior)}, the target descriptor must be
         * {@code call(java.lang.String, int)}
         */
        String value();

        /** @return The component-specific method implementation to target. */
        Class<?> block() default Void.class;
    }

    /** Prevents this component from getting added into an entity group, specified by the group's element type. */
    @Target(ElementType.TYPE)
    @Retention(RetentionPolicy.CLASS)
    public @interface ExcludeGroups{
        /** @return The excluded group's element type. */
        Class<?>[] value();
    }
}
